<?php
/*
Plugin Name: NeuronThemes Share 
Plugin URI: http://neuronthemes.com/soma
Description: A custom share plugin for theme Soma.
Version: 1.0.0
Author: Neuronthemes
Author URI: http://neuronthemes.com
License: GPL2
*/

function neuron_share_social_media() {
    $neuron_shortTitle = get_the_title();
    $neuron_shortURL = get_permalink();
    $output = array();

    $neuron_social_array = array(
		'facebook' => array(
            'icon' => 'facebook-f',
            'class' => 'facebook',
            'link' => 'https://www.facebook.com/sharer/sharer.php?u='. $neuron_shortURL . ''
        ),
		'twitter' => array(
            'icon' => 'twitter',
            'class' => 'twitter',
            'link' => 'https://twitter.com/intent/tweet?text='. $neuron_shortTitle .'&amp;url='. $neuron_shortURL.''
        ),
		'google-plus' => array(
            'icon' => 'google-plus-g',
            'class' => 'google-plus',
            'link' => 'https://plus.google.com/share?url='. $neuron_shortURL .''
        ),
		'linkedin' => array(
            'icon' => 'linkedin-in',
            'class' => 'linkedin',
            'link' => 'https://www.linkedin.com/shareArticle?mini=true&url='. $neuron_shortURL .'&title='. $neuron_shortTitle .''
        ),
		'pinterest' => array(
            'icon' => 'pinterest',
            'class' => 'pinterest',
            'link' => 'https://pinterest.com/pin/create/button/?url='. $neuron_shortURL .'&description='. $neuron_shortTitle .''
        ),
		'tumblr' => array(
            'icon' => 'tumblr',
            'class' => 'tumblr',
            'link' => 'http://www.tumblr.com/share/link?url='. $neuron_shortURL .'&name='. $neuron_shortTitle .''
        )
    );

    $output[] = '<ul>';
    foreach ($neuron_social_array as $neuron_social) {
        $output[] = '<li class='. $neuron_social['class'] .'><a href='. $neuron_social['link'] .'><i class="fab fa-'. $neuron_social['icon'] .'"></i></a></li>';
    }
    $output[] = '</ul>';

    return implode(' ', $output);
}